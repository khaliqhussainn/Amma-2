import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Navigate } from 'react-router-dom';
import Navbar from '../components/NewLanding/Navbar';
import Footer from '../components/NewLanding/Footer';
import api from '../utils/api';
import { 
  Users, 
  Mail, 
  Clock, 
  CheckCircle2, 
  Search, 
  Filter, 
  Download,
  LayoutDashboard,
  MessageSquare,
  BellRing,
  ArrowUpRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const AdminDashboard = () => {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState('members');
  const [data, setData] = useState({
    members: [],
    contactInquiries: [],
    newsletterSubscribers: [],
    comingSoonInquiries: []
  });
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const response = await api.get('/admin/dashboard');
      setData(response.data.data);
    } catch (error) {
      console.error('Failed to fetch admin data', error);
    } finally {
      setLoading(false);
    }
  };

  if (!user || user.role !== 'ADMIN') {
    return <Navigate to="/login" />;
  }

  const filteredData = () => {
    const currentData = data[activeTab] || [];
    if (!searchTerm) return currentData;
    return currentData.filter(item => 
      Object.values(item).some(val => 
        String(val).toLowerCase().includes(searchTerm.toLowerCase())
      )
    );
  };

  const TableHeader = ({ columns }) => (
    <thead className="bg-gray-50">
      <tr>
        {columns.map((col, i) => (
          <th key={i} className="px-6 py-4 text-left text-[10px] font-extrabold text-gray-400 uppercase tracking-widest">
            {col}
          </th>
        ))}
      </tr>
    </thead>
  );

  const StatCard = ({ label, value, icon: Icon, color }) => (
    <div className="bg-white p-6 rounded-[32px] shadow-sm border border-gray-100 flex items-center gap-6">
      <div className={`w-14 h-14 rounded-2xl ${color} flex items-center justify-center`}>
        <Icon size={24} />
      </div>
      <div>
        <p className="text-[10px] font-extrabold text-gray-400 uppercase tracking-widest mb-1">{label}</p>
        <h3 className="text-2xl font-bold text-[#042C53]">{value}</h3>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans">
      <Navbar onJoinClick={() => {}} />
      
      <main className="flex-1 w-full max-w-[1400px] mx-auto p-6 md:p-10 lg:p-12">
        <div className="flex flex-col gap-10">
          
          {/* Admin Header */}
          <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <span className="px-3 py-1 bg-[#AD1F23]/10 text-[#AD1F23] text-[10px] font-bold rounded-full uppercase tracking-wider">Control Center</span>
                <span className="text-gray-300">•</span>
                <span className="text-gray-500 text-sm font-medium">Administrator Access</span>
              </div>
              <h1 className="text-3xl font-bold text-[#042C53]">AMMA Admin Portal</h1>
            </div>
            <div className="flex items-center gap-4">
              <button onClick={fetchDashboardData} className="p-3 bg-white border border-gray-100 rounded-2xl hover:bg-gray-50 transition-all text-[#042C53]">
                <RefreshCw size={20} className={loading ? 'animate-spin' : ''} />
              </button>
              <button className="px-6 py-3 bg-[#AD1F23] text-white rounded-2xl font-bold hover:bg-[#8e191d] transition-all shadow-xl shadow-red-900/10 flex items-center gap-2">
                <Download size={18} />
                Export Data
              </button>
            </div>
          </header>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard label="Total Members" value={data.members.length} icon={Users} color="bg-blue-50 text-blue-600" />
            <StatCard label="Contact Inquiries" value={data.contactInquiries.length} icon={MessageSquare} color="bg-purple-50 text-purple-600" />
            <StatCard label="Newsletter" value={data.newsletterSubscribers.length} icon={BellRing} color="bg-green-50 text-green-600" />
            <StatCard label="Waitlist" value={data.comingSoonInquiries.length} icon={ArrowUpRight} color="bg-orange-50 text-orange-600" />
          </div>

          {/* Table Controls */}
          <div className="bg-white rounded-[40px] shadow-sm border border-gray-100 overflow-hidden">
            <div className="p-8 border-b border-gray-50 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
              <div className="flex items-center gap-2 bg-gray-50 p-1.5 rounded-2xl">
                {[
                  { id: 'members', label: 'Members', icon: Users },
                  { id: 'contactInquiries', label: 'Inquiries', icon: MessageSquare },
                  { id: 'newsletterSubscribers', label: 'Newsletter', icon: BellRing },
                  { id: 'comingSoonInquiries', label: 'Coming Soon', icon: ArrowUpRight }
                ].map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-sm transition-all ${
                      activeTab === tab.id 
                      ? 'bg-white text-[#AD1F23] shadow-sm' 
                      : 'text-gray-500 hover:text-[#042C53]'
                    }`}
                  >
                    <tab.icon size={16} />
                    {tab.label}
                  </button>
                ))}
              </div>

              {/* <div className="relative flex-1 lg:max-w-md">
                <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder={`Search ${activeTab}...`}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-12 pr-6 py-4 bg-gray-50 border-2 border-transparent focus:border-[#AD1F23] focus:bg-white rounded-2xl outline-none transition-all font-medium text-[#042C53]"
                />
              </div> */}
            </div>

            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                {activeTab === 'members' && (
                  <>
                    <TableHeader columns={['Name', 'Email', 'Category', 'Profession', 'Specialty', 'Joined']} />
                    <tbody>
                      {filteredData().map((member, i) => (
                        <tr key={i} className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors">
                          <td className="px-6 py-5">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center font-bold text-[#042C53]">
                                {member.name[0]}
                              </div>
                              <span className="font-bold text-[#042C53]">{member.name}</span>
                            </div>
                          </td>
                          <td className="px-6 py-5 text-sm text-gray-600">{member.email}</td>
                          <td className="px-6 py-5">
                            <span className="px-3 py-1 bg-blue-50 text-blue-600 text-[10px] font-bold rounded-full uppercase">
                              {(member.package || 'Standard').replace(/\(?\s*free\s*\)?/gi, '').trim() || 'Standard'}
                            </span>
                          </td>
                          <td className="px-6 py-5 text-sm font-medium text-gray-700">{member.profession}</td>
                          <td className="px-6 py-5 text-sm text-gray-500">{member.specialty}</td>
                          <td className="px-6 py-5 text-sm text-gray-400 font-medium">
                            {new Date(member.created_at).toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </>
                )}

                {activeTab === 'contactInquiries' && (
                  <>
                    <TableHeader columns={['Sender', 'Subject', 'Message', 'Date']} />
                    <tbody>
                      {filteredData().map((iq, i) => (
                        <tr key={i} className="border-b border-gray-50 hover:bg-gray-50/50">
                          <td className="px-6 py-5">
                            <div className="font-bold text-[#042C53]">{iq.name}</div>
                            <div className="text-xs text-gray-400">{iq.email}</div>
                          </td>
                          <td className="px-6 py-5 text-sm font-bold text-gray-700">{iq.subject}</td>
                          <td className="px-6 py-5 text-sm text-gray-500 max-w-md truncate">{iq.message}</td>
                          <td className="px-6 py-5 text-sm text-gray-400">
                            {new Date(iq.created_at).toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </>
                )}

                {activeTab === 'newsletterSubscribers' && (
                  <>
                    <TableHeader columns={['Email', 'Status', 'Subscribed On']} />
                    <tbody>
                      {filteredData().map((sub, i) => (
                        <tr key={i} className="border-b border-gray-50">
                          <td className="px-6 py-5 font-bold text-[#042C53]">{sub.email}</td>
                          <td className="px-6 py-5">
                            <span className="px-3 py-1 bg-green-50 text-green-600 text-[10px] font-bold rounded-full uppercase">
                              {sub.status}
                            </span>
                          </td>
                          <td className="px-6 py-5 text-sm text-gray-400">
                            {new Date(sub.created_at).toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </>
                )}

                {activeTab === 'comingSoonInquiries' && (
                  <>
                    <TableHeader columns={['Email', 'Interest', 'Registered On']} />
                    <tbody>
                      {filteredData().map((cs, i) => (
                        <tr key={i} className="border-b border-gray-50">
                          <td className="px-6 py-5 font-bold text-[#042C53]">{cs.email}</td>
                          <td className="px-6 py-5 text-sm text-gray-600">{cs.interest_area || 'General'}</td>
                          <td className="px-6 py-5 text-sm text-gray-400">
                            {new Date(cs.created_at).toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </>
                )}
              </table>

              {filteredData().length === 0 && !loading && (
                <div className="py-20 text-center">
                  <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Search className="text-gray-300" size={32} />
                  </div>
                  <h3 className="text-xl font-bold text-[#042C53]">No records found</h3>
                  <p className="text-gray-400">Try adjusting your search or filters.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

// Re-using RefreshCw from previous context if not imported
const RefreshCw = ({ size, className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="M21 2v6h-6"/><path d="M3 12a9 9 0 0 1 15-6.7L21 8"/><path d="M3 22v-6h6"/><path d="M21 12a9 9 0 0 1-15 6.7L3 18"/>
  </svg>
);

export default AdminDashboard;
