import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../utils/api';
import toast from 'react-hot-toast';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMe = async () => {
      const token = localStorage.getItem('token');
      if (token) {
        try {
          const { data } = await api.get('/auth/me');
          setUser(data.user);
        } catch (error) {
          localStorage.removeItem('token');
        }
      }
      setLoading(false);
    };
    fetchMe();
  }, []);

  const login = async (email, password, remember = false) => {
    try {
      const { data } = await api.post('/auth/login', { email, password, remember });
      localStorage.setItem('token', data.token);
      setUser(data.user);
      toast.success('Login successful!');
      return data.user;
    } catch (error) {
      throw error;
    }
  };

  const register = async (userData) => {
    try {
      const { data } = await api.post('/auth/register', userData);
      localStorage.setItem('token', data.token);
      setUser(data.user);
      toast.success('Registration successful!');
      return data.user;
    } catch (error) {
      throw error;
    }
  };

  const updateProfile = async (profileData) => {
    try {
      const { data } = await api.put('/auth/profile', profileData);
      setUser(data.user);
      toast.success('Profile updated successfully!');
      return data.user;
    } catch (error) {
      throw error;
    }
  };

  const googleLogin = async (googleData) => {
    try {
      const { data } = await api.post('/auth/google-login', googleData);
      localStorage.setItem('token', data.token);
      setUser(data.user);
      toast.success('Welcome to AMMA!');
      return data.user;
    } catch (error) {
      throw error;
    }
  };

  const forgotPassword = async (email) => {
    try {
      const { data } = await api.post('/auth/forgot-password', { email });
      toast.success(data.message);
      return data;
    } catch (error) {
      throw error;
    }
  };

  const verifyOtp = async (email, otp) => {
    try {
      const { data } = await api.post('/auth/verify-otp', { email, otp });
      toast.success(data.message);
      return data;
    } catch (error) {
      throw error;
    }
  };

  const resetPassword = async (email, otp, password) => {
    try {
      const { data } = await api.put('/auth/reset-password', { email, otp, password });
      toast.success(data.message);
      return data;
    } catch (error) {
      throw error;
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    setUser(null);
    toast.success('Logged out successfully');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, register, forgotPassword, verifyOtp, resetPassword, googleLogin, updateProfile, loading }}>
      {children}
    </AuthContext.Provider>
  );
};
