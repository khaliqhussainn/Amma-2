const InquiryModel = require('../models/inquiryModel');
const asyncHandler = require('express-async-handler');
const AppError = require('../utils/AppError');

// @desc    Get all dashboard data for admin
// @route   GET /api/admin/dashboard
// @access  Private/Admin
const getAdminDashboard = asyncHandler(async (req, res) => {
    const members = await InquiryModel.getAllMembers();
    const contactInquiries = await InquiryModel.getAllContactInquiries();
    const newsletterSubscribers = await InquiryModel.getAllNewsletterSubscriptions();
    const comingSoonInquiries = await InquiryModel.getAllComingSoonInquiries();

    res.json({
        success: true,
        data: {
            members,
            contactInquiries,
            newsletterSubscribers,
            comingSoonInquiries
        }
    });
});

// @desc    Submit contact inquiry
// @route   POST /api/public/contact
// @access  Public
const submitContactInquiry = asyncHandler(async (req, res) => {
    const { name, email, message } = req.body;
    if (!name || !email || !message) {
        throw new AppError('Please provide name, email and message', 400);
    }
    
    await InquiryModel.createContactInquiry(req.body);
    res.status(201).json({ success: true, message: 'Inquiry sent successfully!' });
});

// @desc    Subscribe to newsletter
// @route   POST /api/public/subscribe
// @access  Public
const subscribeNewsletter = asyncHandler(async (req, res) => {
    const { email } = req.body;
    if (!email) {
        throw new AppError('Please provide an email', 400);
    }
    
    await InquiryModel.subscribeNewsletter(email);
    res.status(201).json({ success: true, message: 'Subscribed successfully!' });
});

// @desc    Submit coming soon interest
// @route   POST /api/public/coming-soon
// @access  Public
const submitComingSoon = asyncHandler(async (req, res) => {
    const { email } = req.body;
    if (!email) {
        throw new AppError('Please provide an email', 400);
    }
    
    await InquiryModel.createComingSoonInquiry(req.body);
    res.status(201).json({ success: true, message: 'Interest registered successfully!' });
});

// @desc    Update member payment status
// @route   PATCH /api/admin/members/:id/status
// @access  Private/Admin
const updateMemberStatus = asyncHandler(async (req, res) => {
    const { status } = req.body;
    const { id } = req.params;

    if (!['PENDING', 'APPROVED', 'BLOCKED'].includes(status)) {
        throw new AppError('Invalid status. Must be PENDING, APPROVED, or BLOCKED', 400);
    }

    const success = await InquiryModel.updateMemberStatus(id, status);
    if (!success) {
        throw new AppError('Member not found or status already set', 404);
    }

    res.json({ success: true, message: `Member status updated to ${status}` });
});

module.exports = {
    getAdminDashboard,
    submitContactInquiry,
    subscribeNewsletter,
    submitComingSoon,
    updateMemberStatus
};
