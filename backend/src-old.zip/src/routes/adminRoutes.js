const express = require('express');
const { getAdminDashboard, updateMemberStatus } = require('../controllers/adminController');
const { protect } = require('../middlewares/authMiddleware');

const router = express.Router();

// Middleware to ensure user is ADMIN
const adminOnly = (req, res, next) => {
    if (req.user && req.user.role === 'ADMIN') {
        next();
    } else {
        res.status(403).json({ success: false, message: 'Not authorized as an admin' });
    }
};

router.get('/dashboard', protect, adminOnly, getAdminDashboard);
router.patch('/members/:id/status', protect, adminOnly, updateMemberStatus);

module.exports = router;
